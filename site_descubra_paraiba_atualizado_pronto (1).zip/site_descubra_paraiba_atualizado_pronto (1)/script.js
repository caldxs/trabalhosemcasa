document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("contato-form");
  const resposta = document.getElementById("resposta");

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    resposta.textContent = "Mensagem enviada com sucesso! Entraremos em contato em breve.";
    form.reset();
  });
});

function limparFormulario() {
    const formulario = document.querySelector("form");
    if (formulario) {
        formulario.reset();
    }
}
